#ifndef FIRST_H
#define FIRST_H

#include <stdlib.h>
#include <stdio.h>
//
//
int exec();

//
//
double* initDoubleArray(int count);

//
//
void freeDoubleArray(double* array);

//
//
double* fillDoubleArray(double* array, int size);

//
//
void showDoubleArray(double* array, int size);
#endif // FIRST_H
