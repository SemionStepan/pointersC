#ifndef FIFTH_H
#define FIFTH_H

#include <stdlib.h>
#include <memory.h>
#include <stdio.h>
#include <string.h>

char* inputString(char* message, int length);
void outputString(char *subString, int count);
int dialog();
int exec(char* string, char* subString);

#endif // FIFTH_H
